from flask import Flask, render_template, request, jsonify, redirect, url_for
import json
import os
from datetime import datetime

app = Flask(__name__)
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')

# ── helpers ──────────────────────────────────────────────────────────────────

def load(name):
    path = os.path.join(DATA_DIR, f'{name}.json')
    if os.path.exists(path):
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    return []

def save(name, data):
    path = os.path.join(DATA_DIR, f'{name}.json')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def next_id(items):
    if not items:
        return 1
    return max(i.get('id', 0) for i in items) + 1

# ── seed reference data ───────────────────────────────────────────────────────

REFS_DEFAULT = {
    'subdivisions_security': [
        'СБ Усть-Каменогорск', 'СБ Риддер', 'СБ Зыряновск',
        'СБ Текели', 'Охрана КПП №1', 'Охрана КПП №2', 'Охрана КПП №3',
    ],
    'violation_types': [
        'Нарушение пропускного режима', 'Проход без пропуска',
        'Проезд без разрешения', 'Несанкционированный вынос/ввоз',
        'Нахождение в запрещённой зоне', 'Нарушение внутриобъектного режима',
        'Нахождение в нетрезвом состоянии', 'Несоблюдение требований охраны',
        'Фото/видеосъёмка без разрешения', 'Другое',
    ],
    'measures': [
        'Устное предупреждение', 'Письменное предупреждение',
        'Задержание', 'Составлен акт', 'Передан руководству',
        'Депремирование', 'Отстранение от работы', 'Увольнение', 'Передача в органы',
    ],
    'cities': ['Усть-Каменогорск', 'Риддер', 'Зыряновск', 'Текели', 'Алматы', 'Астана'],
    'company_subdivisions': [
        'ТОО «Казцинк» — Головной офис',
        'ТОО «Казцинк» — Усть-Каменогорский МК',
        'ТОО «Казцинк» — Риддерский МК',
        'ТОО «Казцинк» — Зыряновский МК',
        'ТОО «Казцинк» — Текелийский МК',
        'ДП «Востокказмедь»', 'ДП «Казцинк-Золото»',
        'ДП «Ульбинский металлургический завод»',
        'ДП «Шемонаихинский медеплавильный завод»',
    ],
    'contractors': [
        'ТОО «СтройМонтаж»', 'ТОО «АзияСервис»', 'ТОО «КазПромСтрой»',
        'ТОО «ТехноСервис»', 'ТОО «МеталлТранс»', 'ТОО «ЭнергоМонтаж»',
        'ООО «РосТехнологии»', 'Другая организация',
    ],
}

for key, val in REFS_DEFAULT.items():
    path = os.path.join(DATA_DIR, f'{key}.json')
    if not os.path.exists(path):
        save(key, val)

# ── VIOLATIONS ────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return redirect(url_for('violations'))

@app.route('/violations')
def violations():
    items = load('violations')
    violators = load('violators')
    violators_map = {v['id']: v for v in violators}
    refs = {k: load(k) for k in REFS_DEFAULT}

    # filters
    f_type = request.args.get('type', '')
    f_city = request.args.get('city', '')
    f_status = request.args.get('status', '')
    f_search = request.args.get('search', '')

    filtered = items
    if f_type:
        filtered = [x for x in filtered if x.get('violation_type') == f_type]
    if f_city:
        filtered = [x for x in filtered if x.get('city') == f_city]
    if f_status:
        filtered = [x for x in filtered if x.get('status') == f_status]
    if f_search:
        s = f_search.lower()
        filtered = [x for x in filtered if
                    s in x.get('violation_type', '').lower() or
                    s in x.get('location', '').lower() or
                    s in x.get('description', '').lower()]

    # attach violator name
    for v in filtered:
        vid = v.get('violator_id')
        if vid and vid in violators_map:
            vt = violators_map[vid]
            v['_violator_name'] = f"{vt.get('last_name','')} {vt.get('first_name','')} {vt.get('middle_name','')}"
        else:
            v['_violator_name'] = ''

    return render_template('violations.html',
        items=filtered, refs=refs, violators=violators,
        filters={'type': f_type, 'city': f_city, 'status': f_status, 'search': f_search},
        total=len(items), shown=len(filtered))

@app.route('/violations/new', methods=['GET', 'POST'])
def violation_new():
    refs = {k: load(k) for k in REFS_DEFAULT}
    violators = load('violators')
    if request.method == 'POST':
        items = load('violations')
        measures = request.form.getlist('measures')
        item = {
            'id': next_id(items),
            'date': request.form.get('date', ''),
            'time': request.form.get('time', ''),
            'security_subdivision': request.form.get('security_subdivision', ''),
            'city': request.form.get('city', ''),
            'violation_type': request.form.get('violation_type', ''),
            'location': request.form.get('location', ''),
            'description': request.form.get('description', ''),
            'measures': measures,
            'status': request.form.get('status', 'Открыто'),
            'violator_id': int(request.form['violator_id']) if request.form.get('violator_id') else None,
            'created_at': datetime.now().isoformat(),
        }
        items.append(item)
        save('violations', items)
        return redirect(url_for('violations'))
    return render_template('violation_form.html', item=None, refs=refs, violators=violators, title='Новое нарушение')

@app.route('/violations/<int:vid>/edit', methods=['GET', 'POST'])
def violation_edit(vid):
    refs = {k: load(k) for k in REFS_DEFAULT}
    violators = load('violators')
    items = load('violations')
    item = next((x for x in items if x['id'] == vid), None)
    if not item:
        return redirect(url_for('violations'))
    if request.method == 'POST':
        item['date'] = request.form.get('date', '')
        item['time'] = request.form.get('time', '')
        item['security_subdivision'] = request.form.get('security_subdivision', '')
        item['city'] = request.form.get('city', '')
        item['violation_type'] = request.form.get('violation_type', '')
        item['location'] = request.form.get('location', '')
        item['description'] = request.form.get('description', '')
        item['measures'] = request.form.getlist('measures')
        item['status'] = request.form.get('status', 'Открыто')
        item['violator_id'] = int(request.form['violator_id']) if request.form.get('violator_id') else None
        save('violations', items)
        return redirect(url_for('violations'))
    return render_template('violation_form.html', item=item, refs=refs, violators=violators, title='Редактировать нарушение')

@app.route('/violations/<int:vid>/delete', methods=['POST'])
def violation_delete(vid):
    items = load('violations')
    save('violations', [x for x in items if x['id'] != vid])
    return redirect(url_for('violations'))

# ── VIOLATORS ─────────────────────────────────────────────────────────────────

@app.route('/violators')
def violators():
    items = load('violators')
    violations_list = load('violations')
    refs = {k: load(k) for k in REFS_DEFAULT}
    f_search = request.args.get('search', '')
    f_type = request.args.get('type', '')
    filtered = items
    if f_search:
        s = f_search.lower()
        filtered = [x for x in filtered if s in f"{x.get('last_name','')} {x.get('first_name','')} {x.get('middle_name','')}".lower()
                    or s in x.get('company_subdivision','').lower()
                    or s in x.get('contractor','').lower()]
    if f_type:
        filtered = [x for x in filtered if x.get('person_type') == f_type]
    # count violations
    for v in filtered:
        v['_violation_count'] = sum(1 for viol in violations_list if viol.get('violator_id') == v['id'])
    return render_template('violators.html', items=filtered, refs=refs,
        filters={'search': f_search, 'type': f_type}, total=len(items), shown=len(filtered))

@app.route('/violators/new', methods=['GET', 'POST'])
def violator_new():
    refs = {k: load(k) for k in REFS_DEFAULT}
    if request.method == 'POST':
        items = load('violators')
        item = {
            'id': next_id(items),
            'last_name': request.form.get('last_name', ''),
            'first_name': request.form.get('first_name', ''),
            'middle_name': request.form.get('middle_name', ''),
            'person_type': request.form.get('person_type', 'Сотрудник компании'),
            'company_subdivision': request.form.get('company_subdivision', ''),
            'contractor': request.form.get('contractor', ''),
            'position': request.form.get('position', ''),
            'doc_number': request.form.get('doc_number', ''),
            'created_at': datetime.now().isoformat(),
        }
        items.append(item)
        save('violators', items)
        return redirect(url_for('violators'))
    return render_template('violator_form.html', item=None, refs=refs, title='Новый нарушитель')

@app.route('/violators/<int:vid>/edit', methods=['GET', 'POST'])
def violator_edit(vid):
    refs = {k: load(k) for k in REFS_DEFAULT}
    items = load('violators')
    item = next((x for x in items if x['id'] == vid), None)
    if not item:
        return redirect(url_for('violators'))
    if request.method == 'POST':
        item['last_name'] = request.form.get('last_name', '')
        item['first_name'] = request.form.get('first_name', '')
        item['middle_name'] = request.form.get('middle_name', '')
        item['person_type'] = request.form.get('person_type', 'Сотрудник компании')
        item['company_subdivision'] = request.form.get('company_subdivision', '')
        item['contractor'] = request.form.get('contractor', '')
        item['position'] = request.form.get('position', '')
        item['doc_number'] = request.form.get('doc_number', '')
        save('violators', items)
        return redirect(url_for('violators'))
    return render_template('violator_form.html', item=item, refs=refs, title='Редактировать нарушителя')

@app.route('/violators/<int:vid>/delete', methods=['POST'])
def violator_delete(vid):
    items = load('violators')
    save('violators', [x for x in items if x['id'] != vid])
    return redirect(url_for('violators'))

# ── REFERENCES ────────────────────────────────────────────────────────────────

@app.route('/refs')
def refs_page():
    refs = {k: load(k) for k in REFS_DEFAULT}
    labels = {
        'subdivisions_security': 'Подразделения охраны',
        'violation_types': 'Виды нарушений',
        'measures': 'Принятые меры',
        'cities': 'Города',
        'company_subdivisions': 'Подразделения компании (ПК и ДП)',
        'contractors': 'Подрядные организации',
    }
    return render_template('refs.html', refs=refs, labels=labels)

@app.route('/refs/<key>/add', methods=['POST'])
def ref_add(key):
    if key not in REFS_DEFAULT:
        return redirect(url_for('refs_page'))
    items = load(key)
    val = request.form.get('value', '').strip()
    if val and val not in items:
        items.append(val)
        save(key, items)
    return redirect(url_for('refs_page'))

@app.route('/refs/<key>/delete', methods=['POST'])
def ref_delete(key):
    if key not in REFS_DEFAULT:
        return redirect(url_for('refs_page'))
    val = request.form.get('value', '')
    items = load(key)
    save(key, [x for x in items if x != val])
    return redirect(url_for('refs_page'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
