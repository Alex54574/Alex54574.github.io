# Система регистрации нарушений — ТОО Казцинк

## Запуск

```bash
pip install flask
python app.py
```

Открыть в браузере: http://localhost:5000

## Структура проекта

```
project/
├── app.py                 # Flask-бэкенд (маршруты, логика)
├── requirements.txt
├── data/                  # JSON-база данных (создаётся автоматически)
│   ├── violations.json    # Реестр нарушений
│   ├── violators.json     # Реестр нарушителей
│   ├── violation_types.json
│   ├── measures.json
│   ├── cities.json
│   ├── subdivisions_security.json
│   ├── company_subdivisions.json
│   └── contractors.json
└── templates/
    ├── base.html          # Общий шаблон (меню, стили)
    ├── violations.html    # Реестр нарушений
    ├── violation_form.html
    ├── violators.html     # Реестр нарушителей
    ├── violator_form.html
    └── refs.html          # Справочники
```

## Функции

- **Реестр нарушений**: список с фильтрами по виду, городу, статусу, поиск
- **Карточка нарушения**: дата, время, подразделение охраны, вид, место, описание, меры, нарушитель, статус
- **Реестр нарушителей**: сотрудники компании и подрядчики, счётчик нарушений
- **Справочники**: все выпадающие списки редактируются — добавление и удаление элементов
- **Данные**: хранятся в JSON-файлах в папке `data/`
